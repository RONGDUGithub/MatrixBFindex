function result=hash3(y,m0) 
%DJB  hash
% result=mod(y,m0)+1;


yy=num2str(y);
yy=int16(yy);
yy1=double(yy);
y0=5381;
for i=1:length(yy1)
 y0=bitshift(y0,5)+y0+yy1(i);
end

result=mod(y0,m0)+1;
end

