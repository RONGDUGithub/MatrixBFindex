k1=[3.5,4,4.5,8.5,9,9.5,15.5,16,16.5]; 

k3=k1;


y=0.005+zeros(17,1);
y1=[0.088388099922804,0.062499930720306,   0.044193875718701,   0.002762134420163,0.001953112969501,  0.001381061764981, 2.157905419801632e-05,1.525872140666095e-05, 1.078956365879744e-05];
y3=[0.089516143798828,  0.062910766601563,  0.044945220947266 ,0.003104095458984,  0.002249603271484, 0.001657409667969,  1.379394531250000e-04,1.226806640625000e-04, 1.075744628906250e-04]; 

plot(k1,y1,'s-')
 % plot(x,y,'--')
 hold on;
  plot(k3,y3,'o-')

 ylabel('$y$','Interpreter','latex','FontSize',18);
 xlabel('$x$','Interpreter','latex','FontSize',18);
  xlabel('k Value');
  ylabel('False Positive Rate'); set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',1);
 h = legend('$Matrix Filter(Theoretic)$','$Matrix Filter(Simulation)$');
 set(h,'Interpreter','latex','Location','NorthEast','FontSize',14)
% %set(gcf,'unit','normalized','position',[0.3,0.2,0.44,0.52])
% set(gca,'FontSize',14);
set(gca,'YTickLabel',{'0��10^-3','1��10^-3','2��10^-3','3��10^-3','4��10^-3','5��10^-3','6��10^-3','7��10^-3'})
set(gca,'xTick',(2:1:28))
%plot(k2,y4)