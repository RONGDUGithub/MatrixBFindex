clear all;
rng('shuffle'); 
digits(10)
format long 
ln2=0.69314718055995;
b=24;
n=2^16;
k0=16;
m0=ceil(k0*n/ln2);
 k1=4;
k2=4;
% k1=power(floor(k0),1/2);
% k2=k1;

m1=ceil(power(m0,0.5));

%m2=ceil(power(m0,0.5)/a);0
m2=ceil(power(m0,0.5));
m1*m2-m0
deltam=m1*m2-m0
global bloom1;
f1_sum=0;

a00=0;
a11=0;
a22=0;
hello=10;
for time=1:hello
bloom1=zeros(m1,m2);
progress=time/hello
test1_1=0;
test2_1=0;
f1=0;
f2=0;
n3=2^b;
y1=randperm(n3)-1;
y2=randperm(n3)-1;
%����K1
for i=1:n    %n��item.
 z1=y1(i);
 z2=y2(i);
 bloomloc1=bloomlookup2(z1,k1,m1); 
 bloomloc2=bloomlookup2(z2,k2,m2);
 bloominsert0(bloomloc1,k1,bloomloc2,k2); 
end

%�����K1 %���Լ�����
for i=n+1:11*n    %n��item.
 z1=y1(i);
 z2=y2(i);
 bloomloc1=bloomlookup2(z1,k1,m1); 
 bloomloc2=bloomlookup2(z2,k2,m2);
for j=1:k1
    for f=1:k2
       if bloom1(bloomloc1(j),bloomloc2(f))==1;
           test1_1=test1_1+1; 
       end
    end       
end
if  test1_1==k1*k2
 f1=f1+1;
end  
     test1_1=0;
end
%����1
f1_sum=f1_sum+f1;
f1=0;
end

p0=exp(-1*k0*n/m0);
k0
f_theo0=(1-p0)^k0
af1_ave=f1_sum/(hello*10*n)
loadfactor1=length(find(bloom1==1))/m0;

load handel
sound(y,Fs)
