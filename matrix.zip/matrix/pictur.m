

x1=0.5:0.05:1;

y=[1	1	1	1	0.9998	0.9987	0.9965	0.9804	0.9271	0.744	0.2425
0.9999	0.9999	0.9999	0.9989	0.9964	0.9914	0.9749	0.9317	0.8207	0.609	0.2463
0.9981	0.9946	0.9894	0.9794	0.959	0.9237	0.8701	0.7862	0.6553	0.4749	0.2437
0.9972	0.9842	0.9612	0.9199	0.848	0.7568	0.6687	0.5668	0.4601	0.3539	0.2366
]
y=fliplr(y)
 plot(x1,y(1,:),'s--')
 
 hold on;
 plot(x1,y(2,:),'o-')
 plot(x1,y(3,:),'^-')
  plot(x1,y(4,:),'^-')
 
 
 


 ylabel('$y$','Interpreter','latex','FontSize',18);
 xlabel('$x$','Interpreter','latex','FontSize',18);
 xlabel('Actural elements inserted');
 ylabel('False Positive Rate'); set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',1);
 h = legend('$\frac{m_{1}}{m_{2}}=1$','$\frac{m_{1}}{m_{2}}=\frac{1}{2}$','$\frac{m_{1}}{m_{2}}=\frac{1}{4}$');
 set(h,'Interpreter','latex','Location','NorthEast','FontSize',15)
% %set(gcf,'unit','normalized','position',[0.3,0.2,0.44,0.52])
% set(gca,'FontSize',14);
set(gca,'xTick',(0:0.2:1))
%plot(k2,y4)