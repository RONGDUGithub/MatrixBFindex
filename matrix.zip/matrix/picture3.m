
x0=[2,3,4,6,8,9,10,12];
x1=[3,6,9,12];
x2=[2,4,6,8,10,12]
x3=x1;
y=0.005+zeros(17,1);
y0=[0.25,0.125,0.0625,0.015625,0.00390625,0.00195312,0.0009765625,0.00024414062];
y1=[0.114226913,0.014349365,0.001755142,0.000349807739257812]
y2=[0.235043716,0.055186462,0.017430496,0.004265976,0.00079803466796875,0.000258255004882812]

y3=[0.115838623,0.016801071,0.002386475,0.000272750854492187] 
 plot(x0,y0,'--')
 hold on;
 plot(x1,y1,'s--')
 plot(x3,y3,'^-')
 plot(x2,y2,'o-')
 %plot(x0,y0,'--')
 


 ylabel('$y$','Interpreter','latex','FontSize',18);
 xlabel('$x$','Interpreter','latex','FontSize',18);
 xlabel('k Value');
 ylabel('False Positive Rate'); set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',1);
 h = legend('$Theoretic$','$\frac{m_{1}}{m_{2}}=1$','$\frac{m_{1}}{m_{2}}=\frac{1}{2}$','$\frac{m_{1}}{m_{2}}=\frac{1}{4}$');
 set(h,'Interpreter','latex','Location','NorthEast','FontSize',15)
% %set(gcf,'unit','normalized','position',[0.3,0.2,0.44,0.52])
% set(gca,'FontSize',14);
set(gca,'xTick',(2:2:42))
%plot(k2,y4)