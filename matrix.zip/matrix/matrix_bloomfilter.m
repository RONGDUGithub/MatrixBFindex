clear all;
rng('shuffle'); 
digits(10)
format long 
ln2=0.69314718055995;
b=24;%29�ǲ��������������
n1=2^8;
n2=2^9; 
k1=2;
k2=4;%�������
a=1
m1=ceil(k1*n1/ln2);
m2=ceil(k2*n2/ln2);

global bloom1;
f1_sum=0;
hello=100;
loadfactor2=0;
h=m1*m2;
for time=1:hello
    loadfactor1=0;
bloom1=zeros(m1,m2);
progress=time/hello
test1_1=0;
test2_1=0;
f1=0;
y1=randperm(n1)+(time-1)*n1;
y2=randperm(n2)+(time-1)*n2;
n3=n1*n2;
y3=zeros(2,n1*n2);

nn=0;
 for belly=1:n1
     for belly2=1:n2
         nn=nn+1;
        y3(:,nn)=[y1(belly);y2(belly2)];
     end
 end
 %���ò���Ԫ�صĸ���,max��h��n1*n2
 n4=ceil(n3);
 %y4=randperm(n4);
y4=randperm(n4);
 %����K1
for i=1:n4  %n��item.
    %�����������·���������
 bloomloc1=bloomlookup2(y3(1,y4(i)),k1,m1);
 bloomloc2=bloomlookup3(y3(2,y4(i)),k2,m2);
 bloominsert0(bloomloc1,k1,bloomloc2,k2); 
end
%��������һ����
y11=randperm(n1)+(time)*n1;
y22=randperm(n2)+(time)*n2;
y33=zeros(2,n1*n2);
n33=n1*n2;
nn=0;
 for belly=1:n1
     for belly2=1:n2
         nn=nn+1;
        y33(:,nn)=[y11(belly);y22(belly2)];
     end
 end
  n44=n33;
 y44=randperm(n1*n2);
 %����K1
%�����K1 %���Լ�����
for i=1:n44    %n��item.  
 bloomloc1=bloomlookup2(y33(1,y44(i)),k1,m1);
 bloomloc2=bloomlookup3(y33(2,y44(i)),k2,m2);
for j=1:k1
    for f=1:k2
       if bloom1(bloomloc1(j),bloomloc2(f))==1;
           test1_1=test1_1+1; 
       end
    end       
end
if  test1_1==k1*k2
 f1=f1+1;
end  

     test1_1=0;
end
f1
%����1
f1_sum=f1_sum+f1;
f1=0;
loadfactor1=length(find(bloom1==1))/h
loadfactor2=loadfactor1+loadfactor2;
end
% test1=length(find(bloom1(:,1)==1))
% test2=length(find(bloom1(:,2)==1))
% test3=length(find(bloom1(:,3)==1))
% test4=length(find(bloom1(:,4)==1))
% test5=length(find(bloom1(:,5)==1))
% test6=length(find(bloom1(:,6)==1))
% test7=length(find(bloom1(:,7)==1))
% test8=length(find(bloom1(:,8)==1))
% test9=length(find(bloom1(:,9)==1))
% test10=length(find(bloom1(:,10)==1))
f_theo0=(0.5)^(k1+k2)
af1_ave=f1_sum/(hello*n44)

loadfactor2=loadfactor2/hello

load handel
sound(y,Fs)