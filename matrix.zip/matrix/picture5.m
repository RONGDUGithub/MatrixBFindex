

x1=[0.2,0.4,0.6,0.8,1];

y1=[0.0000942230224609375,0.000556182861328125,0.002736663818359,0.008011627197266,0.013650131]
y11=[0.065625635,0.122250358,0.175074846,0.217504935,0.256099335];
y2=[0.000225067,0.002212524414063,0.006409072875977,0.010741043090820,0.016631317138672]
y22=[0.065117817252929,0.120029788280833,0.167312289844778,0.210467359147128,0.247210413435598];
y3=[0.000850296,0.003490067,0.006944656,0.010925293,0.015591431] 
y33=[0.063681451,0.121001445,0.170028163,0.213055668,0.249106352];
 plot(x1,y1,'s--')
 
 hold on;
 plot(x1,y2,'o-')
 plot(x1,y3,'^-')
 
 
 


 ylabel('$y$','Interpreter','latex','FontSize',18);
 xlabel('$x$','Interpreter','latex','FontSize',18);
 xlabel('Actural elements inserted');
 ylabel('False Positive Rate'); set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',1);
 h = legend('$\frac{m_{1}}{m_{2}}=1$','$\frac{m_{1}}{m_{2}}=\frac{1}{2}$','$\frac{m_{1}}{m_{2}}=\frac{1}{4}$');
 set(h,'Interpreter','latex','Location','NorthEast','FontSize',15)
% %set(gcf,'unit','normalized','position',[0.3,0.2,0.44,0.52])
% set(gca,'FontSize',14);
set(gca,'xTick',(0:0.2:1))
%plot(k2,y4)