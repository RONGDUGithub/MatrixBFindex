function result=bloomlookup3(y,k,m0) 
result=zeros(1,k);
a=hash1(y,m0);
b=hash2(y,m0);
for i=1:k
 result(i) = mod((i+k)*a+b,m0)+1;
end
end
    
