%һάԪ�ز����׼bloomfilter 
clear all;
format long;
rng('shuffle'); 
digits(20)
ln2=0.69314718055995;
n=2^11;
k1=16;
m1=ceil(k1*n/ln2)


global bloom;

f1_sum=0;

hello=1;
t=10;
for time=1:hello
bloom=zeros(1,m1);
progress=time/hello
test1_1=0;
f1=0;
n3=(t+1)*n;
y1=randperm(n3,(t+1)*n)-1;
%����K1
for i=1:n    %n��item.
 %��׼bloom filter
 z=y1(i);
 bloomloc1=bloomlookup2(z,k1,m1);
 bloominsert3(bloomloc1,k1); 
end
%�����K1 %���Լ�����
for i=n+1:(t+1)*n    %n��item.
  z=y1(i);
 bloomloc1=bloomlookup2(z,k1,m1);  
for j=1:k1
        if  bloom(bloomloc1(j))==1
         test1_1=test1_1+1;  
         end
end
if  test1_1==k1
 f1=f1+1;
end  
     test1_1=0;
end
%����1
f1_sum=f1_sum+f1;
f1=0;

end

p1=exp(-1*k1*n/m1);
f_theo1=(1-p1)^k1
af1_ave=f1_sum/(hello*t*n)
loadfactor1=length(find(bloom==1))/m1
ratio=af1_ave/f_theo1

load handel
sound(y,Fs)
