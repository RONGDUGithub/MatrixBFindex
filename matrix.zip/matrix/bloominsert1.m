function bloominsert1(bloomloc,k)
% increase bloomfilter at $k$ locations [k,bloomloc(i)]
global bloom;
for i=1:k
        bloom(1,bloomloc(i))=1;
end
  end
