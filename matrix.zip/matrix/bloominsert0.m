function bloominsert0(bloomloc1,k1,bloomloc2,k2)
global bloom1
for j=1:k1
for i=1:k2
        bloom1(bloomloc1(j),bloomloc2(i))=1;
end
end
end
