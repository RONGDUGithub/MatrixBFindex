% This is the two dimension bloom filter test.
% Test-data is a sequense of 
clear all;
rng('shuffle'); 
digits(30)
format long 
ln2=0.69314718055995;

n=2^20;
k1=4;
k2=4;
k0=k1*k2;
m0=ceil(k1*k2*n/ln2);

m2=ceil(power(m0*k1/k2,1/2));
m1=ceil(m0/m2);

deltam=m1*m2-m0;
global bloom1;
f1_sum=0;

qq=400;
a00=0;
a11=0;
a22=0;
hello=100;
t=20;

ratio=zeros();
for fy=1:11
    p=0.45+fy*0.05;
    fqq=zeros();
for time=1:hello
bloom1=zeros(m1,m2);
progress=time/hello;
test1_1=0;
test2_1=0;
f1=0;
f2=0;
%n3=(t+1)*n;
n3=3600;
n4=4;
y5=[9867,4562731,7892819,443212,99620,78125,69677737];
y3=randperm(n3,qq);% generate unrepetation
y6=1*(round(rand(1,qq)*(n4-1))+1);
y4=zeros();
for gh=1:qq
    y4(gh)=y5(y6(gh));
end
y=[y3;y4];
%y1=randperm(n3)-1;

%y2=randperm(n3)-1;
%����K1
for i=1:qq    %n��item.
   y1=y(:,i);
 z1=y1(1);
 z2=y1(2);
 bloomloc1=bloomlookup2(z1,k1,m1); 
 bloomloc2=bloomlookup2(z2,k2,m2);
 bloominsert0(bloomloc1,k1,bloomloc2,k2); 
end
bloom10=sum(bloom1);
bloom2=bloom1;

%�Ŷ�
a=find(bloom10>0);
for q0=1:length(a)
    q1=a(q0);
   for q2=1:m1
      if rand(1,1)<p
      else
          bloom2(q2,q1)=1-bloom2(q2,q1);
      end
   end
end

f0=0;
%��֤
for i=1:qq    %n��item.  
 y1=y(:,i);
 z0=y1(1);
 z4=y1(2);
 z00=z0-5;
 z11=z0+5;
 f1=0;
 f100=0;
for z1=z00:z11
 for z9=1:1:n4
     z2=y5(z9);
      bloomloc1=bloomlookup2(z1,k1,m1); 
      bloomloc2=bloomlookup2(z2,k2,m2);
      test1_1=0;
      for j=1:k1
         for f=1:k2
       if bloom2(bloomloc1(j),bloomloc2(f))==1;
           test1_1=test1_1+1;
       end
    end       
      end
       %
  if z1==z0 && z2==z4
        if  test1_1==k1*k2
           f100=f100+1;
       end
  else
        if  test1_1==k1*k2
           f1=f1+1;
       end
  end  
 end
end

if f1>0|| f100==0
    f0=f0+1;
end
end
     test1_1=0;
     fqq(time)=f0;
end


%��������ɹ�����,�������Դ��Ľ��Ӵ
ratio(fy)=mean(fqq/qq)
end










