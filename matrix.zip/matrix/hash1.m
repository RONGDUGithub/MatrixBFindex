function result=hash1(y,m0) 
%BKDR hash
 result=mod(y,m0)+1;
% seed=1313131313131313;
% yy=num2str(y);
% yy=int16(yy);
% yy1=double(yy);
% y0=0;
% for i=1:length(yy1)
%     y0=y0*seed+yy1(i);
% end
% result=mod(y0,m0)+1;
end