

x1=0.5:0.05:1;

y=[0.9998	0.9998	0.9999	0.9991	0.9967	0.9905	0.9745	0.9291	0.8239	0.6021	0.2463
1	0.99985	0.9998	0.999	0.99735	0.99045	0.9717	0.92835	0.83055	0.6562	0.43315
1	1	0.999566667	0.9988	0.996166667	0.9901	0.972366667	0.9299	0.8415	0.694933333	0.583333333
1	0.999925	0.999825	0.999225	0.997025	0.990275	0.971775	0.93125	0.849825	0.736325	0.6927
]
%y=fliplr(y)
 plot(x1,y(1,:),'s--')
 
 hold on;
 plot(x1,y(2,:),'o-')
 plot(x1,y(3,:),'^-')
  plot(x1,y(4,:),'^-')
 
 
 
%Actural elements inserted

 ylabel('$y$','Interpreter','latex','FontSize',18);
 xlabel('$x$','Interpreter','latex','FontSize',18);
 xlabel('p');
 ylabel('Disprove rate'); set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',1);
 h = legend('$N_s=100$','$N_s=200$','$N_s=300$','$N_s=400$');
 set(h,'Interpreter','latex','Location','SouthWest','FontSize',15)
% %set(gcf,'unit','normalized','position',[0.3,0.2,0.44,0.52])
% set(gca,'FontSize',14);
set(gca,'xTick',(0:0.2:1))
 set(gca,'FontWeight','bold','FontSize',15);
%plot(k2,y4)
 %set(h,'Location','NorthEast','FontSize',13,'FontWeight','bold')
 %set(gca,'XTicklabel',{'5%','10%','30%','40%'})
 box off;
 set(gcf, 'PaperPosition', [-0.1 -0.1 14 10]);%设置图的位置，-0.75，0.2表示图片左下角的坐标（pdf页面左下角为（0，0）），26.5，26表示图片的宽高
set(gcf, 'PaperSize', [13 9.8]); %Keep the same paper size，设置pdf纸张的大小，分别表示pdf页面的长宽?
grid off;

saveas(gcf, 'f8.pdf');%保存命令，即在当前目录下生成名为WithMargin的pdf