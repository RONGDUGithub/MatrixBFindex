%xor 
clear all;
rng('shuffle'); 
digits(10)
ln2=0.69314718055995;
b=25;
n=2^16;
k1=6;
m1=ceil(k1*n/ln2)
global bloom1;
f1_sum=0;
hello=1;
for time=1:hello
bloom1=zeros(1,m1);
 
progress=time/hello
test1_1=0;
f1=0;

n3=2^b;%����ȡֵ��Χ�������ϣ��Ӧ������Ϊ�������ظ����ʡ�
y1=randperm(n3)-1;
y2=randperm(n3)-1;
%����K1
for i=1:n    %n��item.
 %��׼bloom filter
  z1=dec2bin(y1(i),b);
 yy1 =(num2str(z1)-'0')';
  z2=dec2bin(y2(i),b);
 yy2 =(num2str(z2)-'0')';
 a=bitxor(yy1,yy2);
 %z1= str2num(char(a'+'0'))
 z1=char(a'+'0');
 z=bin2dec(z1);
 bloomloc1=bloomlookup2(z,k1,m1);
 bloominsert1(bloomloc1,k1); 
end
%�����K1 %���Լ�����
for i=n+1:11*n    %n��item.
  z1=dec2bin(y1(i),b);
 yy1 =(num2str(z1)-'0')';
  z2=dec2bin(y2(i),b);
 yy2 =(num2str(z2)-'0')';
 a=bitxor(yy1,yy2);
 %z1= str2num(char(a'+'0'))
 z1=char(a'+'0');
 z=bin2dec(z1);
 bloomloc1=bloomlookup2(z,k1,m1);
for j=1:k1
        if  bloom1(bloomloc1(j))==1
         test1_1=test1_1+1;  
         end
end
if  test1_1==k1
 f1=f1+1;
end  
     test1_1=0;
end
%����1
f1_sum=f1_sum+f1;
f1=0;
loadfactor1=length(find(bloom1==1))/m1
end
p1=exp(-1*k1*n/m1);
f_theo1=(1-p1)^k1
af1_ave=f1_sum/(hello*10*n)
load handel
sound(y,Fs)
