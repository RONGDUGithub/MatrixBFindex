function bloominsert1(bloomloc,k)
% increase bloomfilter at $k$ locations [k,bloomloc(i)]
global bloom1;
for i=1:k
        bloom1(1,bloomloc(i))=1;
  end
