clear all;
rng('shuffle'); 
digits(10)
format long 
ln2=0.69314718055995;
b=25;
n=2^17;
k0=9;
m0=ceil(k0*n/ln2);
k1=power(floor(k0),1/2);
k2=k1;
a=0.4;
m1=ceil(power(m0,0.5)*a);
%m2=ceil(power(m0,0.5)/a);0
m2=ceil(m0/m1)
deltam=m1*m2-m0
global bloom1;
f1_sum=0;


a00=0;
a11=0;
a22=0;
hello=1;
for time=1:hello
bloom1=zeros(m1,m2);
progress=time/hello
test1_1=0;
test2_1=0;
f1=0;
f2=0;
n3=2^b;
y1=randperm(n3)-1;
y2=randperm(n3)-1;
%����K1
for i=1:n    %n��item.
 z1=y1(i);
 z2=y2(i);
 bloomloc1=bloomlookup2(z1,k1,m1); 
 bloomloc2=bloomlookup2(z2,k2,m2);
 bloominsert0(bloomloc1,k1,bloomloc2,k2); 
end

%�����K1 %���Լ�����
for i=n+1:11*n    %n��item.
 z1=y1(i);
 z2=y2(i);
 bloomloc1=bloomlookup2(z1,k1,m1); 
 bloomloc2=bloomlookup2(z2,k2,m2);
for j=1:k1
    for i=1:k2
       if bloom1(bloomloc1(j),bloomloc2(i))==1;
           test1_1=test1_1+1; 
       end
    end       
end
if  test1_1==k1*k2
 f1=f1+1;
end  
     test1_1=0;
end
%����1
f1_sum=f1_sum+f1;
f1=0;

% loadfactor1=length(find(bloom1==1))/m0
% loadfactor2=length(find(bloom2==1))/m0
% loadfactor3=length(find(bloom33==1))/m1
% loadfactor4=length(find(bloom44==1))/m2
% a1=power(loadfactor1,k1)
% a2= power(loadfactor2,k2)
% a0= (n1/n)*power(loadfactor3,k1)+(n2/n)*power(loadfactor4,k2)
% a00=a00+a0
% a11=a11+a1
% a22=a22+a2
end

p0=exp(-1*k0*n/m0);
f_theo0=(1-p0)^k0
af1_ave=f1_sum/(hello*10*n)
loadfactor1=length(find(bloom1==1))/m0

load handel
sound(y,Fs)
