

x=[3:1:16];
y=0.005+zeros(17,1);
y1=[0.1250,  0.0625, 0.0312, 0.0156,  0.0077,0.0039,   0.0020,   9.7656e-04,     4.8828e-04,  2.4414e-04,   1.2207e-04, 6.1035e-05,    3.0518e-05,1.5259e-05];
y3=[ 0.1250, 0.0620,  0.0310, 0.0155 ,  0.0078,   0.0038,0.0019,   9.6080e-04,    4.9540e-04,  2.2125e-04, 1.2410e-04,  6.7139e-05,   3.6112e-05,   1.6785e-05]; 

 plot(x,y1,'s--')
 % plot(x,y,'--')
 hold on;
 plot(x,y3,'^-')


 ylabel('$y$','Interpreter','latex','FontSize',18);
 xlabel('$x$','Interpreter','latex','FontSize',18);
 xlabel('k Value');
 ylabel('False Positive Rate'); set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',1);
 h = legend('$Theoretic$','$Simulation$');
 set(h,'Interpreter','latex','Location','NorthEast','FontSize',15)
% %set(gcf,'unit','normalized','position',[0.3,0.2,0.44,0.52])
% set(gca,'FontSize',14);
set(gca,'xTick',(3:1:42))
%plot(k2,y4)