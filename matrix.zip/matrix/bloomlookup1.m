function result=bloomlookup1(y,k,m0) 
result=zeros(1,k);
global belly;
for i=1:k
 result(i) = mod(dot(y,belly(:,i)'),m0)+1;
end
end
    
