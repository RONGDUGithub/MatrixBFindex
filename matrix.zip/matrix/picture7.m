

x1=0.5:0.05:1;

y=[1	1	1	1	0.9998	0.9987	0.9965	0.9804	0.9271	0.744	0.2425
0.9999	0.9999	0.9999	0.9989	0.9964	0.9914	0.9749	0.9317	0.8207	0.609	0.2463
0.9981	0.9946	0.9894	0.9794	0.959	0.9237	0.8701	0.7862	0.6553	0.4749	0.2437
0.9972	0.9842	0.9612	0.9199	0.848	0.7568	0.6687	0.5668	0.4601	0.3539	0.2366
]
%y=fliplr(y)
 plot(x1,y(1,:),'s--')
 
 hold on;
 plot(x1,y(2,:),'o-')
 plot(x1,y(3,:),'^-')
  plot(x1,y(4,:),'^-')
 
 
 


 ylabel('$y$','Interpreter','latex','FontSize',18);
 xlabel('$x$','Interpreter','latex','FontSize',18);
 xlabel('p');
 ylabel('Disprove rate'); set(findobj(get(gca,'Children'),'LineWidth',0.5),'LineWidth',1);
 h = legend('$k=5$','$k=4$','$k=3$','$k=2$');
 set(h,'Interpreter','latex','Location','SouthWest','FontSize',15)
% %set(gcf,'unit','normalized','position',[0.3,0.2,0.44,0.52])
% set(gca,'FontSize',14);
set(gca,'xTick',(0:0.2:1))
 set(gca,'FontWeight','bold','FontSize',15);
%plot(k2,y4)
% set(gcf, 'PaperPosition', [0.35 -3.3 18.6 15.4]); %第一个数据是左右挪，第二个数据是上下挪
%  set(gcf, 'PaperSize', [15 11]); %Keep the same paper size，设置pdf纸张的大小，分别表示pdf页面的长宽?
 box off;
 %saveas(gcf, 'f7.pdf');%保存命令，即在当前目录下生成名为WithMargin的pdf
  %set(h,'Location','NorthEast','FontSize',13,'FontWeight','bold')
 %set(gca,'XTicklabel',{'5%','10%','30%','40%'})

 set(gcf, 'PaperPosition', [-0.1 -0.1 14 10]);%设置图的位置，-0.75，0.2表示图片左下角的坐标（pdf页面左下角为（0，0）），26.5，26表示图片的宽高
set(gcf, 'PaperSize', [13 9.8]); %Keep the same paper size，设置pdf纸张的大小，分别表示pdf页面的长宽?
grid off;

saveas(gcf, 'f7.pdf');%保存命令，即在当前目录下生成名为WithMargin的pdf