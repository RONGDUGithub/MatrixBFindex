function result=department(y) 
b=fix(log10(y))+1;
 b1=floor(b/2);
result(1)=rem(y,10^b1);
result(2)=(y-result(1))/10^b1;
 end
    
